// 1 = <div class="wall"></div> 
// 2 = <div class="player"></div>
// 3 = <div class="bg"></div>
// 4 = <div class="coin"> </div>
// 5 = <div class="ghost1"> </div> 
// 6 = <div class="ghost2"> </div> 
// 7 = <div class="ghost3"> </div> 

var world = [[1,2,1,1,1,1,1,1,1], 
             [1,4,3,4,3,4,3,1,1],
             [1,3,1,1,1,1,3,1,1],
             [1,3,4,3,3,3,3,3,3], 
             [1,3,1,3,1,1,1,1,1],
             [1,3,3,5,6,7,4,3,1],
             [1,1,1,1,1,1,1,3,1], 
             [1,3,3,4,3,3,4,3,1],
             [1,3,1,1,1,1,1,1,1],
             [1,3,4,3,4,4,3,4,1], 
             [1,1,1,1,1,1,1,3,1],
             [1,3,4,3,3,4,3,4,1],
             [1,1,1,1,1,1,1,1,1],] 

function drawMap() {
    for(var yaxis = 0; yaxis<world.length; yaxis++){
        console.log(world[yaxis])
        for (var xaxis = 0; xaxis< world[yaxis].length; xaxis++){
            console.log(world[yaxis][xaxis])
            if (world[yaxis][xaxis] == 1){
                document.getElementById('map').innerHTML+="<div class='wall'></div>  "
                }

        }
    }
}
drawMap();